%% Cappellini Matteo 4822622

function [geom_model] = BuildTree()
%%% BuildTree function
%
% This function should build the tree of frames for the chosen manipulator.
% Inputs: 'None'
% Outputs: The tree of frames.

% geom_model is a 3-dimensional matlab matrix, suitable for defining tree of
% frames. geom_model should represent the transformation matrix between the i-th and j-th
% frames at q = 0. 
% 
% geom_model(row,col,link_idx). This structure represents the geometric
% model of the manipulator. 

%0T1
geom_model(1,1,1) = 1; geom_model(1,2,1) = 0; geom_model(1,3,1) = 0; geom_model(1,4,1) = 0;
geom_model(2,1,1) = 0; geom_model(2,2,1) = 1; geom_model(2,3,1) = 0; geom_model(2,4,1) = 0;
geom_model(3,1,1) = 0; geom_model(3,2,1) = 0; geom_model(3,3,1) = 1; geom_model(3,4,1) = 0.105;
geom_model(4,1,1) = 0; geom_model(4,2,1) = 0; geom_model(4,3,1) = 0; geom_model(4,4,1) = 1;

%1T2
geom_model(1,1,2) = 0; geom_model(1,2,2) = 1; geom_model(1,3,2) = 0; geom_model(1,4,2) = 0;
geom_model(2,1,2) = 0; geom_model(2,2,2) = 0; geom_model(2,3,2) = 1; geom_model(2,4,2) = 0;
geom_model(3,1,2) = 1; geom_model(3,2,2) = 0; geom_model(3,3,2) = 0; geom_model(3,4,2) = 0.110;
geom_model(4,1,2) = 0; geom_model(4,2,2) = 0; geom_model(4,3,2) = 0; geom_model(4,4,2) = 1;

%2T3
geom_model(1,1,3) = 0; geom_model(1,2,3) = 0; geom_model(1,3,3) = 1; geom_model(1,4,3) = 0.100;
geom_model(2,1,3) = 0; geom_model(2,2,3) = -1; geom_model(2,3,3) = 0; geom_model(2,4,3) = 0;
geom_model(3,1,3) = 1; geom_model(3,2,3) = 0; geom_model(3,3,3) = 0; geom_model(3,4,3) = 0;
geom_model(4,1,3) = 0; geom_model(4,2,3) = 0; geom_model(4,3,3) = 0; geom_model(4,4,3) = 1;

%3T4
geom_model(1,1,4) = 0; geom_model(1,2,4) = 0; geom_model(1,3,4) = 1; geom_model(1,4,4) = 0;
geom_model(2,1,4) = 0; geom_model(2,2,4) = -1; geom_model(2,3,4) = 0; geom_model(2,4,4) = 0;
geom_model(3,1,4) = 1; geom_model(3,2,4) = 0; geom_model(3,3,4) = 0; geom_model(3,4,4) = 0.325;
geom_model(4,1,4) = 0; geom_model(4,2,4) = 0; geom_model(4,3,4) = 0; geom_model(4,4,4) = 1;

%4T5
geom_model(1,1,5) = 0; geom_model(1,2,5) = 0; geom_model(1,3,5) = 1; geom_model(1,4,5) = 0.095;
geom_model(2,1,5) = -1; geom_model(2,2,5) = 0; geom_model(2,3,5) = 0; geom_model(2,4,5) = 0;
geom_model(3,1,5) = 0; geom_model(3,2,5) = -1; geom_model(3,3,5) = 0; geom_model(3,4,5) = 0;
geom_model(4,1,5) = 0; geom_model(4,2,5) = 0; geom_model(4,3,5) = 0; geom_model(4,4,5) = 1;

%5T6
geom_model(1,1,6) = -1; geom_model(1,2,6) = 0; geom_model(1,3,6) = 0; geom_model(1,4,6) = 0;
geom_model(2,1,6) = 0; geom_model(2,2,6) = -1; geom_model(2,3,6) = 0; geom_model(2,4,6) = 0;
geom_model(3,1,6) = 0; geom_model(3,2,6) = 0; geom_model(3,3,6) = 1; geom_model(3,4,6) = 0.095;
geom_model(4,1,6) = 0; geom_model(4,2,6) = 0; geom_model(4,3,6) = 0; geom_model(4,4,6) = 1;

%6T7
geom_model(1,1,7) = 0; geom_model(1,2,7) = -1; geom_model(1,3,7) = 0; geom_model(1,4,7) = 0;
geom_model(2,1,7) = 0; geom_model(2,2,7) = 0; geom_model(2,3,7) = -1; geom_model(2,4,7) = 0;
geom_model(3,1,7) = 1; geom_model(3,2,7) = 0; geom_model(3,3,7) = 0; geom_model(3,4,7) = 0.235;
geom_model(4,1,7) = 0; geom_model(4,2,7) = 0; geom_model(4,3,7) = 0; geom_model(4,4,7) = 1;

%7T8
geom_model(1,1,8) = 0; geom_model(1,2,8) = 0; geom_model(1,3,8) = 1; geom_model(1,4,8) = 0.120;
geom_model(2,1,8) = -1; geom_model(2,2,8) = 0; geom_model(2,3,8) = 0; geom_model(2,4,8) = 0;
geom_model(3,1,8) = 0; geom_model(3,2,8) = -1; geom_model(3,3,8) = 0; geom_model(3,4,8) = 0;
geom_model(4,1,8) = 0; geom_model(4,2,8) = 0; geom_model(4,3,8) = 0; geom_model(4,4,8) = 1;

end

