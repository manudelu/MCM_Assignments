%% Cappellini Matteo 4822622

function [biTei] = GetDirectGeometry(q, geom_model, jointType)
%%% GetDirectGeometryFunction

% Inputs: 
% q : links current position ; 
% geom_model : vector of matrices containing the transformation matrices from link
% i to link j
% jointType: vector of size numberOfLinks identiying the joint type, 0 for revolute, 1 for
% prismatic.

% Outputs :
% biTei vector of matrices containing the transformation matrices 
% from link i to link j for the input q. 
% The size of geom_model is equal to (4,4,numberOfLinks)

numberOfLinks = length(jointType);

for i = 1:numberOfLinks
    biTei(:,:,i) = DirectGeometry(q(i),geom_model(:,:,i),jointType(i));
end

end